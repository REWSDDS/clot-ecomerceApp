import 'package:alfa/core/constants/color/color_const.dart';
import 'package:alfa/core/model/address_model.dart';
import 'package:alfa/core/utils/local_db/add_addres_service.dart';
import 'package:alfa/core/widgets/app_back_button.dart';
import 'package:alfa/core/widgets/custom_app_bar.dart';
import 'package:alfa/core/widgets/custom_app_button.dart';
import 'package:alfa/core/widgets/custom_text_field.dart';
import 'package:alfa/features/settings/pages/add_address/provider/add_address_provider.dart';
import 'package:alfa/features/settings/pages/address/page/address_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddressAddScreen extends StatefulWidget {
  const AddressAddScreen({
    super.key,
  });
  @override
  State<AddressAddScreen> createState() => _AddressAddScreenState();
}

class _AddressAddScreenState extends State<AddressAddScreen> {
  final TextEditingController _addressController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _stateController = TextEditingController();
  final TextEditingController _zipCodeController = TextEditingController();

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AddAddressProvider>(context).address;
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
      },
      child: Scaffold(
        floatingActionButton:  Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child:provider.isEmpty ?CustomAppButon(
            title: "Save",
            onTap: () {
              Provider.of<AddAddressProvider>(context,listen: false).address.add(AddressModel(street: _addressController.text, city: _cityController.text, state: _stateController.text, zipCode: _zipCodeController.text));
              Navigator.push(
                  context,
                  CupertinoPageRoute(
                      builder: (_) => const AddressScreen()));
            },
          ):Row(children: [
              Expanded(
                child: CustomAppButon(
                  title: "Delete",
                  backGroundColor: ColorConst.red,
                  onTap: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (_) => const AddressScreen()));
                  },
                ),
              ),
              SizedBox(width: 20,),
              Expanded(
                child: CustomAppButon(
                  title: "Save",
                  onTap: () {
                   if(_addressController.text.isEmpty){
                         showModalBottomSheet(context: context,sheetAnimationStyle: AnimationStyle(curve: Curves.linearToEaseOut),builder: (context){
                           return Text("This box Empty");
                         });
                   }
                   else{
                     Navigator.pop(context);
                   }
                  },
                ),
              )
            ],),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
        appBar: const CustomAppBar(
          leading: AppBackButton(),
          isTitleText: true,
          titleText: "Add Address",
        ),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                SizedBox(
                  height: 42,
                ),
                CustomTextField(
                  hintText: "Street Address",
                  controller: _addressController,
                  hasLeading: false,
                  borderRadius: 8,
                ),
                SizedBox(
                  height: 12,
                ),
                CustomTextField(
                  hintText: "City",
                  controller: _cityController,
                  hasLeading: false,
                  borderRadius: 8,
                ),
                SizedBox(
                  height: 12,
                ),
                Row(
                  children: [
                    Expanded(
                        child: CustomTextField(
                      hintText: "State",
                      controller: _stateController,
                      hasLeading: false,
                      borderRadius: 8,
                    )),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                        child: CustomTextField(
                      hintText: "Zip Code",
                      controller: _zipCodeController,
                      hasLeading: false,
                      borderRadius: 8,
                    )),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
