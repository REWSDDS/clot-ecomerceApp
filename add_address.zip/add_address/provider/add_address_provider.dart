import 'package:alfa/core/model/address_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:hive/hive.dart';

class AddAddressProvider extends ChangeNotifier{
 List<AddressModel> address = [
 ];
}