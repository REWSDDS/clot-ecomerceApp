import 'package:alfa/core/constants/color/color_const.dart';
import 'package:alfa/core/constants/icons/icons_const.dart';
import 'package:alfa/core/model/address_model.dart';
import 'package:alfa/core/utils/check_current_mode.dart';
import 'package:alfa/core/utils/local_db/add_addres_service.dart';
import 'package:alfa/core/widgets/app_back_button.dart';
import 'package:alfa/core/widgets/custom_app_bar.dart';
import 'package:alfa/core/widgets/custom_app_button.dart';
import 'package:alfa/features/settings/pages/add_address/page/address_add_screen.dart';
import 'package:alfa/features/settings/pages/add_address/provider/add_address_provider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

class AddressScreen extends StatelessWidget {
  const AddressScreen({super.key,});

  get builder => null;
  @override
  Widget build(BuildContext context) {
    List<Future<AddressModel>> title = [

    ];
    int index = 0;
    final mode =checkCurrentTheme(MediaQuery.platformBrightnessOf(context))==AppThemeMode.light;
    final provider = Provider.of<AddAddressProvider>(context).address;
    final text = Theme.of(context).textTheme;
    return Scaffold(
      floatingActionButton: provider.isEmpty?const SizedBox():FloatingActionButton(onPressed: (){Navigator.push(context, CupertinoPageRoute(builder: (_) => AddressAddScreen()));},child: SvgPicture.asset(IconsConst.increment,colorFilter: ColorFilter.mode(mode?ColorConst.white:ColorConst.black, BlendMode.srcIn),width: 35,),),
      appBar:const CustomAppBar(
        leading: AppBackButton(),
        isTitleText: true,
        titleText: "Address",
      ),
      body: SafeArea(
          child: Column(
            mainAxisAlignment: provider.isEmpty?MainAxisAlignment.center:MainAxisAlignment.start,
            children: [
             provider.isEmpty?const SizedBox():const SizedBox(height: 42,),
              provider.isEmpty?Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(width: 150,child: Image.asset(IconsConst.location)),
                    Text("You do not have an address",style: text.bodyLarge!.copyWith(fontWeight: FontWeight.bold),),
                    CustomAppButon(title: "Add Address", onTap: (){
                     Navigator.push(context, CupertinoPageRoute(builder: (_) => AddressAddScreen()));
                    },width: 140,),
                    const SizedBox(height: 100)
                  ],
                ),
              ):ListView.builder(
                itemCount: provider.length,
                shrinkWrap: true, itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: double.infinity,
                  height: 72,
                  margin: const EdgeInsets.only(bottom: 12,left: 24,right: 24),
                  decoration: BoxDecoration(
                      color: mode?ColorConst.grey:ColorConst.darkBg,
                      borderRadius: BorderRadius.circular(8)
                  ),
                  child: ListTile(
                    leading:SizedBox(width:185,child: Text("${Provider.of<AddAddressProvider>(context).address[index].street},${Provider.of<AddAddressProvider>(context).address[index].city},${Provider.of<AddAddressProvider>(context).address[index].state},${Provider.of<AddAddressProvider>(context).address[index].zipCode}",style: Theme.of(context).textTheme.headlineSmall!.copyWith(overflow: TextOverflow.ellipsis,fontSize: 16),)) ,
                    trailing:Padding(
                      padding: const EdgeInsets.only(top: 18),
                      child: GestureDetector(onTap:(){Navigator.push(context, CupertinoPageRoute(builder: (_) => AddressAddScreen()));},child: Text("Edit",style: Theme.of(context).textTheme.headlineSmall!.copyWith(overflow: TextOverflow.ellipsis,color: ColorConst.kPrimary),)),
                    ) ,
                  ),
                );
              },

              ),
            ],
          ),
      ),
    );
  }
}
